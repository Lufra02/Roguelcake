# Game Feel en MAD System

En el Inspector añade la acción a un objeto activo y asígnala a la lista de acciones del evento. Para impactos crea el contexto con el punto de contacto y la dirección deseada. Configura duración en segundos. Los pulsos utilizan por defecto tiempo real, reinician su fase al recibir otro evento y restauran el valor inicial al terminar o desactivar el componente. Una acción debe ser la única escritora de su propiedad. Usa pivotes hijos distintos para combinar efectos, y un solo controlador de vibración por mando.

## Qué se reutiliza

El prototipo incluía `PlaySound`, `MADSoundManager`, un prefab temporal de audio y assets para impacto/explosión. La acción de sonido del paquete conserva la selección de volumen y pitch entre rangos independientes. Las clases históricas dependen del proyectil anterior o del administrador global. El comportamiento de área histórico aplica empuje físico. Su uso como respuesta de mundo necesita la decisión de cada juego. El muestreo de los scripts del prototipo no identificó acciones específicas para FOV, vibración, desenfoque o hit stop. Los equipos aportan animaciones, sonidos, materiales, VFX y referencias propias.

| Técnica | Cómo configurarla | Qué comprobar en el juego |
| --- | --- | --- |
| Anticipation | MADVisualPulse, Anticipation, sobre el pivote del actor. Emitir al preparar el ataque. | La señal precede a la ventana de ataque real. |
| Speed ramping | MADAnimationPulse con la curva de velocidad. | Usar Animator decorativo sin root motion ni eventos que gobiernen reglas. |
| Squash & stretch | MADVisualPulse, SquashStretch. Eje local de elongación. | El collider queda en el padre. |
| Hit stop | MADAnimationPulse congela un Animator visual. MADGameplayHitStop con MADGameplayClock pausa el tiempo escalado de gameplay durante un impacto. El menú del juego puede compartir el reloj con SetPaused. | Comprueba dos impactos solapados, una pausa de menú concurrente y el retorno a la escala anterior. Los sistemas con tiempo real siguen avanzando. |
| Hit reactions | MADVisualPulse, HitReaction. El evento trae la dirección de reacción en coordenadas mundiales. | Orientación de la reacción y concordancia con el impacto. |
| Follow-through | MADVisualPulse, FollowThrough. Ajustar amplitud, eje y oscilaciones. | La recuperación visual permite la siguiente acción. |
| Impact VFX | MADImpactEffect con prefab decorativo y límite de instancias por acción. | Orienta el eje +Z del prefab con Direction. Para alinear con la normal envía esa normal. |
| Weapon trails | MADTrailWindow sobre TrailRenderer en la punta del arma, Emitting inicialmente apagado. | Material compatible con el pipeline y duración acorde con el golpe. |
| Motion smears | MADVisualPulse, MotionSmear, sobre una silueta decorativa. | Estiramiento corto y recuperación completa. |
| Dynamic motion blur | En el sample SRP, el menú de posprocesado genera un VolumeProfile con Motion Blur nativo, una cámara móvil y MADVolumePulse. | Activa posprocesado y vectores de movimiento. Comprueba el resultado en la GPU y el pipeline objetivo. |
| Hit flash | MADHitFlash con SpriteRenderer y color de destino o Renderer 3D superpuesto inicialmente apagado. | El tint se multiplica por la textura. Para blanco sólido usar un overlay con material apropiado. |
| Secondary motion | MADVisualPulse, SecondaryMotion, sobre un accesorio con pivote propio. La amplitud está en grados. | Oscilación angular en respuesta al evento. |
| Sound design | Acción MAD de sonido con clip y rangos de volumen y pitch. | Escuchar ataques superpuestos y verificar mezcla y colas. |
| Camera shake | MADVisualPulse, CameraShake. Coloca el pivote entre el rig controlado y la cámara, como padre de la cámara. | Eje y amplitud, incluida amplitud cero. Mantener la dirección de apuntado en el rig estable. |
| FOV kick | MADFieldOfViewPulse en una cámara de perspectiva con FOV controlado por esta acción. | Lente, accesibilidad y restauración. |
| Focus kick | La misma demo crea un segundo perfil con Depth of Field Gaussian en URP o Manual en HDRP. El botón de enfoque pulsa el peso y lo restaura. | Comprueba la lectura de las columnas cerca y lejos, el soporte del dispositivo y el retorno a peso cero. |
| Haptics | Importa el sample de vibración con Input System. En el menú de la demo, activa o detén el impulso de motores bajo y alto. PlayerInput permite seleccionar el mando de un jugador. | Prueba el corte al desactivar o perder foco y la sensación en un mando físico compatible. |
| World response | MADImpactEffect con prefab de polvo, marca o fragmentos y vida en segundos de juego. Para reacciones persistentes conectar código del juego con Run Script. | Limpieza y presupuesto. El límite es local a cada instancia de la acción. |

## Dependencias y alcance de las pruebas

El núcleo visual usa Transform, Camera, Animator, Renderer y TrailRenderer de Unity. Los samples SRP y Haptics se importan por separado desde Package Manager. El primero requiere SRP Core y un renderer URP/HDRP que soporte el efecto. Crea un Volume dedicado, asigna un perfil con los overrides y parámetros activados, configura la cámara para posprocesado y deja weight en 0 como reposo. En Built-in, conecta tu solución de posprocesado mediante Run Script. Haptics requiere el paquete Input System y un dispositivo con motores de vibración. En multijugador asigna el PlayerInput correcto. Al pausar o desconectar, el juego puede llamar StopEffect.

Las pruebas de MADFeelTests cubren repetición y restauración de escala, desactivación, restauración de FOV y cámara ortográfica. La escena final de cada equipo requiere revisión visual, auditiva y en mando. El catálogo de GameDes del 13 de noviembre de 2026 fija los 18 nombres y el objetivo expresivo. La tabla describe componentes y configuraciones disponibles. La calidad perceptual, la mezcla de efectos y el confort necesitan pruebas con jugadores.
