using System;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;

namespace Maiiki.MAD.Samples.Editor
{
    public static class MADPostProcessDemoMenu
    {
        public static VolumeProfile CreateProfile(bool highDefinition, bool blur)
        {
            string prefix = highDefinition ? "UnityEngine.Rendering.HighDefinition." : "UnityEngine.Rendering.Universal.";
            var type = TypeCache.GetTypesDerivedFrom<VolumeComponent>()
                .FirstOrDefault(t => t.FullName == prefix + (blur ? "MotionBlur" : "DepthOfField"));
            if (type == null) throw new InvalidOperationException("Falta la dependencia del pipeline: " + prefix);
            var profile = ScriptableObject.CreateInstance<VolumeProfile>();
            var effect = profile.Add(type);
            if (blur)
            {
                Set(effect, "intensity", 0.8f);
                if (!highDefinition) Set(effect, "mode", "CameraAndObjects");
                else Set(effect, "cameraMotionBlur", true);
            }
            else if (highDefinition)
            {
                Set(effect, "focusMode", "Manual");
                Set(effect, "nearFocusStart", 0f);
                Set(effect, "nearFocusEnd", 2f);
                Set(effect, "farFocusStart", 5f);
                Set(effect, "farFocusEnd", 8f);
            }
            else
            {
                Set(effect, "mode", "Gaussian");
                Set(effect, "gaussianStart", 4f);
                Set(effect, "gaussianEnd", 8f);
                Set(effect, "gaussianMaxRadius", 1.5f);
            }
            return profile;
        }

        // Both optional pipelines share VolumeParameter, with different override classes.
        // Resolve only at authoring time; the saved profile keeps native typed components.
        private static void Set(VolumeComponent effect, string field, object value)
        {
            var parameter = (VolumeParameter)effect.GetType().GetField(field).GetValue(effect);
            var property = parameter.GetType().GetProperty("value");
            if (value is string enumValue) value = Enum.Parse(property.PropertyType, enumValue);
            property.SetValue(parameter, value);
            parameter.overrideState = true;
        }

        [MenuItem("MAD/Demo/Posprocesado en el pipeline activo")]
        public static void Open()
        {
            var pipeline = GraphicsSettings.currentRenderPipeline;
            bool hd = pipeline && pipeline.GetType().FullName == "UnityEngine.Rendering.HighDefinition.HDRenderPipelineAsset";
            if (!hd && (!pipeline || pipeline.GetType().FullName != "UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset"))
            {
                Debug.LogWarning("Abre este ejemplo en un proyecto con URP o HDRP activo.");
                return;
            }
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            BuildScene(hd);
        }

        public static void BuildScene(bool hd)
        {
            EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects);
            if (hd)
            {
                // HDRP interprets the default directional light in lux.
                var sun = UnityEngine.Object.FindFirstObjectByType<Light>();
                if (sun)
                {
                    sun.lightUnit = LightUnit.Lux;
                    sun.intensity = 50000f;
                }
            }
            var camera = Camera.main;
            camera.transform.SetPositionAndRotation(new Vector3(0f, 1.6f, -3f), Quaternion.identity);
            var extraType = TypeCache.GetTypesDerivedFrom<MonoBehaviour>().First(t => t.FullName == (hd ?
                "UnityEngine.Rendering.HighDefinition.HDAdditionalCameraData" :
                "UnityEngine.Rendering.Universal.UniversalAdditionalCameraData"));
            var data = camera.GetComponent(extraType) ?? camera.gameObject.AddComponent(extraType);
            if (!hd) extraType.GetProperty("renderPostProcessing").SetValue(data, true);
            var controller = new GameObject("MAD · Blur y Focus").AddComponent<MADPostProcessDemo>();
            for (int i = 0; i < 2; i++)
            {
                bool blur = i == 0;
                var profile = CreateProfile(hd, blur);
                profile.name = blur ? "MAD Motion Blur" : "MAD Focus";
                string path = AssetDatabase.GenerateUniqueAssetPath("Assets/" + profile.name + ".asset");
                AssetDatabase.CreateAsset(profile, path);
                foreach (var effect in profile.components) AssetDatabase.AddObjectToAsset(effect, profile);
                EditorUtility.SetDirty(profile);
                var go = new GameObject(profile.name);
                var volume = go.AddComponent<Volume>();
                volume.isGlobal = true;
                volume.priority = 100f + i;
                volume.weight = 0f;
                volume.sharedProfile = profile;
                var pulse = go.AddComponent<MADVolumePulse>();
                pulse.effectVolume = volume;
                pulse.peakWeight = 1f;
                pulse.duration = 1.4f;
                if (blur) controller.blur = pulse; else controller.focus = pulse;
            }
            controller.view = camera;
            // Create render-pipeline materials explicitly. Built-in materials can render magenta after a pipeline switch.
            var lightBar = MakeMaterial(hd, "MAD Light", new Color(0.88f, 0.91f, 0.94f));
            var darkBar = MakeMaterial(hd, "MAD Dark", new Color(0.12f, 0.22f, 0.37f));
            var marker = GameObject.CreatePrimitive(PrimitiveType.Cube);
            marker.name = "Blanco móvil";
            marker.transform.position = new Vector3(0f, 1.7f, 1f);
            marker.transform.localScale = new Vector3(0.4f, 0.95f, 0.3f);
            marker.GetComponent<MeshRenderer>().sharedMaterial = MakeMaterial(hd, "MAD Target", new Color(1f, 0.38f, 0.05f));
            controller.movingTarget = marker.transform;
            for (int row = 0; row < 4; row++)
                for (int col = -3; col <= 3; col++)
                {
                    var block = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    block.GetComponent<MeshRenderer>().sharedMaterial = ((col + row) % 2 == 0) ? lightBar : darkBar;
                    block.transform.position = new Vector3(col * 1.8f, 1.4f, 2f + row * 3f);
                    block.transform.localScale = new Vector3(0.45f, 2f, 0.45f);
                }
            AssetDatabase.SaveAssets();
            Selection.activeGameObject = controller.gameObject;
        }

        private static Material MakeMaterial(bool hd, string name, Color color)
        {
            var shader = Shader.Find(hd ? "HDRP/Lit" : "Universal Render Pipeline/Lit");
            if (!shader) throw new InvalidOperationException("Falta el shader Lit del pipeline seleccionado.");
            var material = new Material(shader) { name = name };
            material.SetColor("_BaseColor", color);
            if (hd) material.SetColor("_EmissiveColor", color * 1.5f);
            AssetDatabase.CreateAsset(material, AssetDatabase.GenerateUniqueAssetPath("Assets/" + name + ".mat"));
            return material;
        }
    }
}
