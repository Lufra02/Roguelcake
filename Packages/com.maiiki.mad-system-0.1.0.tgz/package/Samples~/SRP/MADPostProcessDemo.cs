using UnityEngine;

namespace Maiiki.MAD.Samples
{
    public sealed class MADPostProcessDemo : MonoBehaviour
    {
        public Camera view;
        public MADVolumePulse blur;
        public MADVolumePulse focus;
        public Transform movingTarget;
        private Vector3 initial;
        private Quaternion initialRotation;
        private Vector3 targetOrigin;
        private void Start()
        {
            if (view) { initial = view.transform.position; initialRotation = view.transform.rotation; }
            if (movingTarget) targetOrigin = movingTarget.position;
        }
        private void Update()
        {
            float phase = Time.time * 3f;
            if (view)
            {
                view.transform.position = initial + Vector3.right * Mathf.Sin(phase) * 1.2f;
                view.transform.rotation = initialRotation * Quaternion.Euler(0f, -8f * Mathf.Sin(phase), 0f);
            }
            if (movingTarget)
            {
                movingTarget.position = targetOrigin + Vector3.right * (2.2f * Mathf.Sin(phase * 1.6f));
                movingTarget.rotation = Quaternion.Euler(0f, phase * 60f, 0f);
            }
        }
        private void OnGUI()
        {
            GUILayout.BeginArea(new Rect(18f, 18f, 250f, 170f), GUI.skin.box);
            GUILayout.Label("MAD · cámara en desplazamiento");
            if (GUILayout.Button("Pulso de movimiento") && blur) blur.Execute(null);
            if (GUILayout.Button("Pulso de enfoque") && focus) focus.Execute(null);
            GUILayout.EndArea();
        }
    }
}
