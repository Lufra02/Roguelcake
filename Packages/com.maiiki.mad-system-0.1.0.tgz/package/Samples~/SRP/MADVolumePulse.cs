using UnityEngine;
using UnityEngine.Rendering;

namespace Maiiki.MAD
{
    // Add to an event and point it at a dedicated Volume for one override.
    [AddComponentMenu("MAD/Feel/SRP Volume Pulse")]
    public sealed class MADVolumePulse : MADTimedAction
    {
        public Volume effectVolume;
        [Range(0f, 1f)] public float peakWeight = 0.5f;
        private Volume activeVolume;
        private float baseWeight;

        protected override bool Begin(MADContext context)
        {
            if (!effectVolume) return false;
            activeVolume = effectVolume;
            baseWeight = activeVolume.weight;
            return true;
        }
        protected override void Apply(float phase)
        {
            if (activeVolume) activeVolume.weight = Mathf.Lerp(peakWeight, baseWeight, phase);
        }
        protected override void Restore()
        {
            if (activeVolume) activeVolume.weight = baseWeight;
        }
    }
}
