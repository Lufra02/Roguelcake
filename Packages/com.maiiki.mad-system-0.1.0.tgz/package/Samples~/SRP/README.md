# Motion Blur y Focus

Importa este ejemplo con URP o HDRP instalado y activo. En **MAD → Demo → Posprocesado en el pipeline activo**, guarda tu escena si Unity lo solicita. Se abre una escena nueva con cámara móvil, blancos a varias profundidades y dos perfiles nativos guardados en Assets. Pulsa Play y activa cada efecto con su botón.

El pulso de movimiento usa intensidad 0.8. En URP el enfoque es Gaussian con inicio 4 y fin 8. En HDRP usa Manual con rangos cercano 0–2 y lejano 5–8. Para reutilizar solamente los perfiles elige **Perfiles URP** o **Perfiles HDRP** según el pipeline. Para integrar un efecto asigna el perfil a un Volume dedicado, peso inicial cero, añade MAD Volume Pulse y enlaza la acción con el evento del juego. Comprueba el posprocesado, máscaras de cámara, vectores de movimiento y calidad del render en la plataforma de destino.
