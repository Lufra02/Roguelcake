using UnityEngine;
using UnityEngine.InputSystem;

namespace Maiiki.MAD.Samples
{
    [RequireComponent(typeof(MADHapticPulse))]
    public sealed class MADHapticDemo : MonoBehaviour
    {
        private MADHapticPulse pulse;
        private void Awake() => pulse = GetComponent<MADHapticPulse>();
        public void Trigger() { pulse.Execute(null); }
        private void OnGUI()
        {
            GUILayout.BeginArea(new Rect(18f, 18f, 310f, 160f), GUI.skin.box);
            GUILayout.Label(Gamepad.current != null ? Gamepad.current.displayName : "Conecta un mando con vibración.");
            if (GUILayout.Button("Probar pulso de impacto")) Trigger();
            if (GUILayout.Button("Detener vibración")) pulse.StopEffect();
            GUILayout.EndArea();
        }
    }
}
