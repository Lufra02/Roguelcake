# Prueba de vibración

Importa el ejemplo con Input System instalado y activo. Abre **MAD → Demo → Pulso háptico**, pulsa Play, conecta un mando compatible y pulsa el botón de impacto. El emisor comienza con motor bajo 0.35 y alto 0.65. Ambos vuelven a cero en 0.30 s. El botón de detención y la desactivación del componente cancelan el pulso.

En un juego local multijugador asigna el PlayerInput del participante. La opción Use Current Pad In Single Player dirige la prueba al mando actual cuando no hay un PlayerInput asignado. La prueba de comandos con mando virtual mide lo enviado por el software; verifica la sensación física en el dispositivo objetivo.
