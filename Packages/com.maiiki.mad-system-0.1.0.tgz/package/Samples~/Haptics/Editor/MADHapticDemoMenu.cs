using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace Maiiki.MAD.Samples.Editor
{
    public static class MADHapticDemoMenu
    {
        [MenuItem("MAD/Demo/Pulso háptico")]
        public static void Open()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects);
            var go = new GameObject("MAD · Impacto háptico");
            var pulse = go.AddComponent<MADHapticPulse>();
            pulse.useCurrentPadInSinglePlayer = true;
            pulse.lowMotor = 0.35f;
            pulse.highMotor = 0.65f;
            pulse.duration = 0.3f;
            go.AddComponent<MADHapticDemo>();
            Selection.activeGameObject = go;
        }
    }
}
