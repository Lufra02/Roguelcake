using UnityEngine;
using UnityEngine.InputSystem;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Feel/Gamepad Haptic Pulse")]
    public sealed class MADHapticPulse : MADTimedAction
    {
        [Tooltip("With local multiplayer, assign the PlayerInput of the player receiving the event.")]
        public PlayerInput player;
        public bool useCurrentPadInSinglePlayer;
        [Range(0f, 1f)] public float lowMotor = 0.25f;
        [Range(0f, 1f)] public float highMotor = 0.4f;
        private Gamepad activePad;

        private void OnApplicationFocus(bool focused)
        {
            if (!focused) StopEffect();
        }

        private void OnApplicationPause(bool paused)
        {
            if (paused) StopEffect();
        }

        protected override bool Begin(MADContext context)
        {
            activePad = null;
            if (player)
            {
                foreach (var device in player.devices)
                    if (device is Gamepad pad) { activePad = pad; break; }
            }
            else if (useCurrentPadInSinglePlayer) activePad = Gamepad.current;
            return activePad != null && activePad.added;
        }
        protected override void Apply(float phase)
        {
            if (activePad != null && activePad.added)
                activePad.SetMotorSpeeds(lowMotor * (1f - phase), highMotor * (1f - phase));
        }
        protected override void Restore()
        {
            if (activePad != null && activePad.added) activePad.SetMotorSpeeds(0f, 0f);
            activePad = null;
        }
    }
}
