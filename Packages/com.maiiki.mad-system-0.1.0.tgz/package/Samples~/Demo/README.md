# Demo de proyectiles

Importa «Demo mínima» desde Package Manager. Abre **MAD → Demo → Abrir escena de proyectiles** y pulsa Play. La cámara encuadra un emisor y un blanco. Al recibir un impacto, el blanco aumenta de tamaño brevemente y la consola indica cuántos disparos ha recibido. La escena utiliza la física 3D del plano XZ.

## Llevar el disparo a una escena

1. Crea un objeto hijo en el punto de salida del arma. Añade **MAD Projectile Emitter**. Asigna el prefab **MADProjectile** y un descriptor de **Runtime/Projectiles/Presets**. En **Owner** indica la raíz del tirador para excluir sus colliders. En un personaje 3D el frente local es +Z. En un personaje 2D elige **XY** y orienta +Y hacia el blanco.
2. Invoca `emitter.Fire(direccionMundo)` desde el controlador existente, o activa **Auto Fire** y ajusta **Interval** en segundos de tiempo de juego. El cambio de descriptor solo afecta a los nuevos disparos. Configura los descriptores como datos compartidos y evita mutarlos durante el vuelo.
3. Para personalizar el prefab, crea una variante en Assets. Elige **Target Layers** con los colliders que deben interceptar el disparo. La trayectoria barre el centro del proyectil mediante raycast por paso fijo. La esfera es una representación visual. En XY se aplica la configuración de triggers de Physics 2D. Un cuerpo compuesto entrega el GameObject de su Rigidbody o Rigidbody2D como destino. Sin cuerpo cada objeto con collider es independiente.
4. En **On Impact**, **On Area Target** o **MAD Chain Targets → On Link**, añade **MAD Run Script** u otra MAD Action y conecta tu receptor. Los eventos entregan la fuente, el objetivo cuando exista, la posición y la dirección. El origen del disparo está en `context.Source.GetComponent<Maiiki.MAD.MADProjectile>().Owner`. En **On End** el objetivo puede faltar al expirar la vida. **While Traveling** emite como máximo una vez por paso fijo. Para finalizar explícitamente usa `Finish(objetivo)`.

| Descriptor | Resultado inicial |
| --- | --- |
| IceLine | Disparo recto. Usa On Impact para las reacciones de hielo que defina el juego. |
| FireArcArea | Arco de 1.2 s, altura 3. El impacto o fin de vida consulta un área de radio 5 y aplica impulso 5 a cuerpos dinámicos. On Area Target permite responder por objetivo. |
| ElectricRadialChain | Ocho rayos distribuidos en el plano de disparo. El prefab conecta On Impact a MAD Chain Targets, que emite hasta dos enlaces a colliders cercanos distintos dentro de radio 3 por salto. Ajusta las capas para seleccionar enemigos. La selección se reinicia por impacto y proyectil. |
| HistoricalBounce | Recto, velocidad 10, vida 10 s, tres rebotes y evento de viaje cada 0.5 s. |
| HistoricalZigzag | Zigzag relativo al eje de disparo, velocidad 10, vida 10 s, cinco rebotes y evento de viaje cada segundo. |

Las variantes históricas recuperan los parámetros de `madProjectile_bounce` y `madProjectile_simple`. Los valores radiales y de área proceden de `madBehavior_divide` y `madBehavior_areaDamage`. El impulso afecta a Rigidbody y Rigidbody2D según el plano. Las acciones del equipo pueden aplicar daño, status o cambios visuales. Los proyectos URP/HDRP pueden asignar el material de su juego al MeshRenderer del prefab.
