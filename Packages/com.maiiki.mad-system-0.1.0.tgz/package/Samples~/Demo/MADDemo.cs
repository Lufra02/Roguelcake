using UnityEngine;

namespace Maiiki.MAD.Samples
{
    // Place on an empty object in an empty scene, assign the supplied prefab
    // and IceLine descriptor, then press Play. The target flashes on each hit.
    public sealed class MADDemo : MonoBehaviour
    {
        public MADProjectile projectile;
        public MADProjectileDescriptor settings;
        public int Hits { get; private set; }

        void Start()
        {
            if (!projectile || !settings) { Debug.LogError("MAD Demo: asigna el prefab y el descriptor.", this); return; }
            GameObject target = GameObject.CreatePrimitive(PrimitiveType.Cube);
            target.name = "MAD Demo Target";
            target.transform.SetParent(transform, false);
            target.transform.localPosition = Vector3.forward * 4f;
            var counter = target.AddComponent<MADDemoImpact>();
            counter.demo = this;

            // A scene-local inactive template lets us connect a receiver without editing the asset.
            var template = Instantiate(projectile, transform);
            template.gameObject.SetActive(false);
            template.onImpact.SetActions(counter);
            var emitter = gameObject.AddComponent<MADProjectileEmitter>();
            emitter.prefab = template;
            emitter.descriptor = settings;
            emitter.owner = template.gameObject; // the target is also a child of this demo root
            emitter.interval = 0.8f;
            emitter.autoFire = true;
        }

        public void CountHit() { Hits++; }
    }
}
