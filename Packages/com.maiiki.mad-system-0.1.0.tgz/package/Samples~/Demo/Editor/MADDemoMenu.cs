using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Maiiki.MAD.Samples.Editor
{
    public static class MADDemoMenu
    {
        const string Presets = "Packages/com.maiiki.mad-system/Runtime/Projectiles/Presets/";

        [MenuItem("MAD/Demo/Abrir escena de proyectiles")]
        public static void CreateScene()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(Presets + "MADProjectile.prefab");
            var settings = AssetDatabase.LoadAssetAtPath<MADProjectileDescriptor>(Presets + "IceLine.asset");
            if (!prefab || !settings || !prefab.TryGetComponent<MADProjectile>(out var projectile))
                throw new System.InvalidOperationException("Falta el prefab MADProjectile o el descriptor IceLine.");
            EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            var demo = new GameObject("MAD Demo").AddComponent<MADDemo>();
            demo.projectile = projectile;
            demo.settings = settings;
            var camera = Camera.main;
            camera.transform.position = new Vector3(5, 5, -4);
            camera.transform.LookAt(new Vector3(0, 0, 2));
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
        }
    }
}
