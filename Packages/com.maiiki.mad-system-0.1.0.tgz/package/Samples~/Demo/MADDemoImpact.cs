using UnityEngine;

namespace Maiiki.MAD.Samples
{
    public sealed class MADDemoImpact : MADAction
    {
        public MADDemo demo;
        float flash;
        public override void Execute(MADContext context)
        {
            if (context.Target != gameObject) return;
            demo.CountHit();
            flash = 0.15f;
            transform.localScale = Vector3.one * 1.3f;
            Debug.Log("MAD Demo · impacto " + demo.Hits, this);
        }
        void Update()
        {
            if (flash <= 0f) return;
            flash -= Time.deltaTime;
            if (flash <= 0f) transform.localScale = Vector3.one;
        }
    }
}
