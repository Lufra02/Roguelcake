# MAD System 0.1.0 para Unity 6

## Instalar y probar

1. Guarda el archivo `com.maiiki.mad-system-0.1.0.tgz` en una ubicación accesible para el proyecto. En **Window → Package Management → Package Manager**, abre **+ → Install package from tarball** y elige el archivo. Si el equipo comparte el proyecto mediante Git, conserva el tarball y una referencia local reproducible para los demás equipos. El proyecto MADSystem-Unity6 ya contiene la edición del paquete bajo `Packages/com.maiiki.mad-system`.
2. Selecciona **MAD System → Samples → Demo mínima → Import**. Abre **MAD → Demo → Abrir escena de proyectiles** y pulsa **Play**. Un emisor dispara automáticamente contra un cubo. Cada acierto incrementa el contador de consola y dilata el blanco brevemente. El menú ofrece guardar la escena anterior.
3. En tu juego, crea una variante del prefab `Runtime/Projectiles/Presets/MADProjectile.prefab` dentro de Assets. Elige el material del pipeline del juego, las capas de colisión y el descriptor. Añade un **MAD Projectile Emitter** al punto de disparo, asigna la variante, el descriptor y la raíz del tirador en **Owner**. Usa XZ con colliders 3D o XY con colliders 2D. Llama a `Fire(direccionMundo)` desde la acción de disparo existente. **Auto Fire** tiene su propio intervalo en segundos.

## Ajustar un preset para un arma

La variante del prefab y su descriptor son dos assets diferentes. El campo **Descriptor** del emisor decide qué configuración recibe cada disparo. Dos emisores que apuntan al mismo descriptor leen los mismos valores.

Para partir de **IceLine**, copia su archivo `IceLine.asset` desde la carpeta de presets del paquete a una carpeta propia bajo `Assets`, con un nombre como `HieloLocal.asset`. Copia únicamente el archivo `.asset` para que Unity asigne un GUID nuevo al importarlo. Arrastra **HieloLocal** al campo **Descriptor** del emisor que quieres ajustar. Cambia **Speed** en la copia y comprueba que el segundo emisor sigue apuntando a **IceLine**. Para recuperar el comportamiento inicial, vuelve a asignar **IceLine**. En el Inspector también puedes deshacer y rehacer una reasignación con el menú **Edit**.

## Conectar una acción

Abre la variante en Prefab Mode y añade **MAD Run Script** y el componente receptor al mismo prefab. En **On Impact → Actions**, pulsa **+** y asigna **MAD Run Script** al nuevo espacio. Conserva **MAD Chain Targets** en el primer espacio para que la electricidad siga encadenando objetivos. En **Callback → +**, arrastra el componente receptor y elige **Recibir** en la sección dinámica de `MADContext`. Guarda la variante y dispara contra un objeto con collider. Este receptor escribe el nombre del objetivo en la consola.

```csharp
using Maiiki.MAD;
using UnityEngine;

public class ReceptorImpacto : MonoBehaviour
{
    public void Recibir(MADContext impacto)
    {
        if (impacto.Target)
            Debug.Log($"Impacto en {impacto.Target.name}", impacto.Target);
    }
}
```

Un evento ejecuta en orden las acciones habilitadas. Puedes sumar **MAD Play Sounds**, arrastrar clips al componente y ajustar por separado los rangos de volumen y pitch. Para escuchar mientras termina el proyectil, el componente crea una voz independiente. **MAD Event Emitter** permite emitir desde una animación o script usando `Emit()` o `EmitTo(objetivo)`. El contexto incluye emisor, objetivo opcional, posición y dirección en coordenadas mundiales.

## Integrar por juego

| Juego | Conexión inicial | Comprobación en la escena del equipo |
| --- | --- | --- |
| Nine Lives Below | Usa **FireArcArea** para fuego parabólico, **IceLine** para hielo recto y **ElectricRadialChain** para ocho disparos radiales. Conecta reacción por blanco a **On Area Target**, congelación a **On Impact**, y propagación eléctrica a **MAD Chain Targets → On Link**. El equipo selecciona el descriptor desde AbilityManager al desbloquear la invocación con PlayerAbilityUnlocker.Unlock y dispara cuando MagicManager.TrySpend confirma el gasto y conserva la autoridad sobre fragmentos y estados. Keket conserva su controlador. | Prueba desbloqueo y disparo por separado. Comprueba que el dueño queda excluido, que un área detecta al enemigo y que cada rayo encadena hasta el límite del descriptor. |
| Return to Chronos | Soul puede habilitar el emisor mientras esté equipado. Ajusta intervalo y boca del arma. Mind puede emitir al confirmar el golpe en AtaqueJugador.AplicarGolpe, y Body al consumir el salto válido en ControladorJugador.EjecutarSalto. Usa dos emisores si ambas señales necesitan acciones distintas. | Al salir de Soul desactiva el autofire. Verifica un único efecto por golpe o salto y que la lógica del juego conserva sus tiempos. |
| Little Byte | Integración opcional sobre un enemigo o miniboss. Un adaptador del equipo puede suscribirse a `EnemyHealth.OnDamaged` y `OnDied`, y llamar a `MADCharacter.NotifyHit` y `NotifyDeath`. Desuscribe al desactivar. Un pivote hijo puede recibir destello o reacción visual. | Prueba daño, muerte y reactivación junto al movimiento y los efectos que ya usa el enemigo. |
| Cute Death Island | En PlayerCombat, después del cobro en TryToShoot y desde el punto de salida ShootProjectile, selecciona un descriptor según la progresión y llama una vez a `Fire`. Conecta daño y respuesta de gomitas mediante acciones. Para enemigos reutilizados por pooling añade **MAD Character** y notifica impacto y muerte desde sus transiciones existentes. | Mantén Auto Fire apagado. Coteja rebotes, alcance, explosión y modificador huge con la ruta existente. Verifica un solo cobro de masa y una sola aplicación de daño. Prueba mejora, retorno del enemigo al pool, reaparición y pausa en una copia jugable. |

## Dependencias por módulo

| Módulo | Requiere y cómo se integra |
| --- | --- |
| Eventos y personajes | GameObjects activos y referencias serializadas a componentes. **MAD Character** puede acompañar a un jugador o NPC. El controlador del juego conserva salud y locomoción. Usa el namespace `Maiiki.MAD` explícitamente donde ya exista una clase histórica homónima. |
| Steering | **MAD Chase** recibe un Transform y un umbral de llegada. Emite **On Arrive** una vez al entrar. Por defecto calcula `DesiredVelocity` para el motor existente. Activa **Move Transform** solo si Chase debe controlar la posición. **MAD Flee** proporciona velocidad de huida. |
| Proyectiles | Descriptores ScriptableObject compartidos y estado independiente por disparo. Física 3D o 2D según plano, colliders en los blancos y Rigidbody si se desea impulso. Los raycasts barren la línea central. Para ajustar progresión duplica o selecciona presets antes del disparo. |
| Audio | Módulo Audio, clips y un AudioListener en escena. Grupo de mezcla opcional. |
| Game Feel | Animator, pivote visual, Renderer, Camera o prefab de efecto según acción. **Pulsos de Volume** requiere URP/HDRP, un Volume con perfil y soporte de Motion Blur o Depth of Field. **Vibración de mando** requiere Input System y mando compatible. Importa cada ejemplo opcional únicamente con sus dependencias disponibles. [Catálogo de 18 técnicas](Documentation~/GameFeel.md) |

Los parámetros de **HistoricalBounce** y **HistoricalZigzag** proceden de los descriptores históricos. Los presets recuperan el impulso de área y el conteo radial originales. La división histórica al destruirse puede componerse conectando **On End** a un emisor secundario con un prefab terminal. El paquete separa esos componentes de las dependencias antiguas de Input y HUD. [Uso y valores de los cinco presets](Samples~/Demo/README.md)

Para ejecutar las pruebas del paquete, instala Unity Test Framework, agrega `"testables": ["com.maiiki.mad-system"]` al nivel raíz de `Packages/manifest.json` (conserva otras entradas existentes) y ejecuta **Test Runner → PlayMode**. Las pruebas de física requieren Play Mode.

