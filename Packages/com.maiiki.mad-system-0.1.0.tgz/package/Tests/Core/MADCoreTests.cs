using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;

namespace Maiiki.MAD.Tests
{
    public sealed class MADCoreTests
    {
        private GameObject actor;
        private GameObject target;

        [SetUp]
        public void CreateActors()
        {
            actor = new GameObject("Actor");
            target = new GameObject("Target");
        }

        [TearDown]
        public void RemoveActors()
        {
            Object.DestroyImmediate(actor);
            Object.DestroyImmediate(target);
        }

        [Test]
        public void EventPreservesOrderAndIgnoresRecursiveDispatchAndDisabledActions()
        {
            var signal = new MADEvent();
            var first = actor.AddComponent<MADRunScript>();
            var second = actor.AddComponent<MADRunScript>();
            var disabled = actor.AddComponent<MADRunScript>();
            disabled.enabled = false;
            var trace = new List<int>();
            var expected = new MADContext(actor, target, Vector3.one, Vector3.right);
            first.Callback.AddListener(context =>
            {
                Assert.That(context, Is.SameAs(expected));
                trace.Add(1);
                signal.Raise(context);
            });
            disabled.Callback.AddListener(_ => trace.Add(99));
            second.Callback.AddListener(_ => trace.Add(2));
            signal.SetActions(first, null, disabled, second);
            signal.Raise(expected);
            CollectionAssert.AreEqual(new[] { 1, 2 }, trace);
        }

        [Test]
        public void CharacterDelegatesLifeAndEmitsDeathOnceUntilReenabled()
        {
            var character = actor.AddComponent<MADCharacter>();
            var callback = actor.AddComponent<MADRunScript>();
            int deaths = 0;
            callback.Callback.AddListener(context =>
            {
                Assert.That(context.Source, Is.EqualTo(actor));
                Assert.That(context.Target, Is.EqualTo(target));
                deaths++;
            });
            character.OnDeath.SetActions(callback);
            character.NotifyDeath(target);
            character.NotifyDeath(target);
            Assert.That(deaths, Is.EqualTo(1));
            actor.SetActive(false);
            actor.SetActive(true);
            // OnEnable is guaranteed in Play Mode. In Edit Mode ordinary behaviours
            // do not receive all lifecycle callbacks, so this fixture only tests the living instance.
            if (Application.isPlaying)
            {
                character.NotifyDeath(target);
                Assert.That(deaths, Is.EqualTo(2));
            }
        }

        [Test]
        public void FleeProvidesVelocityOnlyInsideThreatRadius()
        {
            var flee = actor.AddComponent<MADFlee>();
            flee.Threat = target.transform;
            flee.DetectionDistance = 2f;
            target.transform.position = Vector3.right;
            Assert.That(flee.DesiredVelocity.x, Is.LessThan(0f));
            target.transform.position = Vector3.right * 3;
            Assert.That(flee.DesiredVelocity, Is.EqualTo(Vector3.zero));
            target.transform.position = Vector3.zero;
            Assert.That(flee.DesiredVelocity.x, Is.GreaterThan(0f));
            Assert.That(actor.transform.position, Is.EqualTo(Vector3.zero));
        }

        [Test]
        public void ChaseEmitsOncePerEntranceAndDoesNotMoveAnExternalMotor()
        {
            var chase = actor.AddComponent<MADChase>();
            var relay = actor.AddComponent<MADRunScript>();
            int arrivals = 0;
            relay.Callback.AddListener(_ => arrivals++);
            chase.OnArrive.SetActions(relay);
            chase.Target = target.transform;
            chase.ArrivalDistance = 1;
            target.transform.position = Vector3.right * 4;
            chase.Step(5);
            Assert.That(actor.transform.position, Is.EqualTo(Vector3.zero));
            Assert.That(chase.DesiredVelocity.x, Is.GreaterThan(0f));
            chase.MoveTransform = true;
            chase.Step(5);
            chase.Step(5);
            Assert.That(actor.transform.position.x, Is.EqualTo(3f).Within(0.0001f));
            Assert.That(arrivals, Is.EqualTo(1));
            target.transform.position = Vector3.left * 3;
            chase.Step(5);
            Assert.That(arrivals, Is.EqualTo(2));
        }
    }
}
