using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Maiiki.MAD.Tests
{
    public sealed class MADCharacterBaseTests
    {
        private GameObject actor;
        [SetUp] public void Create() => actor = new GameObject("Character");
        [TearDown] public void Remove() => Object.DestroyImmediate(actor);

        [UnityTest]
        public IEnumerator OptionalMotorMovesOnlyWhileAliveAndPoolClearsIntent()
        {
            var character = actor.AddComponent<MADCharacter>();
            character.SetDesiredVelocity(Vector3.right * 20f);
            Assert.That(character.DesiredVelocity.magnitude, Is.EqualTo(6f).Within(0.001f));
            var start = actor.transform.position;
            yield return null;
            Assert.That(actor.transform.position, Is.EqualTo(start));
            actor.AddComponent<MADTransformMotor>();
            yield return null;
            yield return null;
            Assert.That(actor.transform.position.x, Is.GreaterThan(start.x));
            character.NotifyDeath(null);
            var deadPosition = actor.transform.position;
            yield return null;
            Assert.That(actor.transform.position, Is.EqualTo(deadPosition));
            actor.SetActive(false);
            actor.SetActive(true);
            Assert.IsTrue(character.CanAct);
            Assert.AreEqual(Vector3.zero, character.DesiredVelocity);
        }

        [Test]
        public void OptionalHealthReportsAcceptedHitsAndSingleDeath()
        {
            var character = actor.AddComponent<MADCharacter>();
            var vitality = actor.AddComponent<MADVitality>();
            var hit = actor.AddComponent<MADRunScript>();
            var death = actor.AddComponent<MADRunScript>();
            int hits = 0, deaths = 0;
            hit.Callback.AddListener(_ => hits++);
            death.Callback.AddListener(_ => deaths++);
            character.OnHit.SetActions(hit);
            character.OnDeath.SetActions(death);
            Assert.IsFalse(vitality.TakeDamage(float.NaN, null));
            Assert.IsTrue(vitality.TakeDamage(30, null));
            Assert.AreEqual(70f, vitality.Current);
            Assert.IsTrue(vitality.TakeDamage(90, null));
            Assert.IsFalse(vitality.TakeDamage(1, null));
            Assert.AreEqual(2, hits);
            Assert.AreEqual(1, deaths);
        }

        [UnityTest]
        public IEnumerator SpawnTickAndInteractionUseTheCurrentActivation()
        {
            var character = actor.AddComponent<MADCharacter>();
            var spawn = actor.AddComponent<MADRunScript>();
            var tick = actor.AddComponent<MADRunScript>();
            var interaction = actor.AddComponent<MADRunScript>();
            int spawns = 0, ticks = 0, interactions = 0;
            spawn.Callback.AddListener(_ => spawns++);
            tick.Callback.AddListener(_ => ticks++);
            interaction.Callback.AddListener(context =>
            {
                Assert.AreEqual(actor, context.Target);
                interactions++;
            });
            character.OnSpawn.SetActions(spawn);
            character.OnTick.SetActions(tick);
            character.OnInteraction.SetActions(interaction);
            actor.SetActive(false);
            actor.SetActive(true);
            yield return null;
            Assert.AreEqual(1, spawns);
            Assert.AreEqual(0, ticks);
            character.EmitTick = true;
            yield return null;
            yield return null;
            Assert.Greater(ticks, 0);
            character.NotifyInteraction(actor);
            character.NotifyDeath(null);
            character.NotifyInteraction(actor);
            int finalTicks = ticks;
            yield return null;
            Assert.AreEqual(finalTicks, ticks);
            Assert.AreEqual(1, interactions);
        }

        [Test]
        public void StateChangesAndContactPayloadReachActions()
        {
            var character = actor.AddComponent<MADCharacter>();
            var action = actor.AddComponent<MADRunScript>();
            int count = 0;
            action.Callback.AddListener(context =>
            {
                Assert.AreEqual("Guardia", character.CurrentState);
                Assert.AreEqual(actor, context.Source);
                count++;
            });
            character.OnStateChanged.SetActions(action);
            character.ChangeState("Guardia");
            character.ChangeState("Guardia");
            Assert.AreEqual(1,count);
            var impact = actor.AddComponent<MADRunScript>();
            MADContext contact = null;
            impact.Callback.AddListener(context => contact = context);
            character.OnImpact.SetActions(impact);
            character.NotifyImpact(null, Vector3.up * 2, Vector3.left);
            Assert.AreEqual(Vector3.up * 2, contact.Position);
            Assert.AreEqual(Vector3.left, contact.Direction);
        }
    }
}

