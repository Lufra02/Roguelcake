using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Maiiki.MAD.Tests
{
    public sealed class MADProjectileTests
    {
        readonly List<Object> created = new List<Object>();

        T Track<T>(T obj) where T : Object { created.Add(obj); return obj; }
        GameObject At(string name, Vector3 position)
        {
            var obj = Track(new GameObject(name));
            obj.transform.position = position;
            return obj;
        }

        [TearDown]
        public void TearDown()
        {
            foreach (Object item in created) if (item) Object.DestroyImmediate(item);
            created.Clear();
        }

        [UnityTest]
        public IEnumerator RayHitsTriggerBeyondOwnerAndEndsOnce()
        {
            if (!Application.isPlaying) Assert.Ignore("Play Mode");
            var settings = Track(ScriptableObject.CreateInstance<MADProjectileDescriptor>());
            var origin = new Vector3(1000f, 0f, 1000f);
            var owner = At("Owner", origin);
            owner.AddComponent<BoxCollider>();
            var target = At("Target", origin + Vector3.forward);
            target.AddComponent<BoxCollider>().isTrigger = true;
            var probe = target.AddComponent<MADProjectileProbe>();
            var shot = At("Shot", origin).AddComponent<MADProjectile>();
            shot.onImpact.SetActions(probe);
            shot.onEnd.SetActions(probe);
            Assert.IsTrue(shot.Launch(settings, MADFlightPlane.XZ, Vector3.forward, owner));
            Assert.IsFalse(shot.Launch(settings, MADFlightPlane.XZ, Vector3.forward, owner));
            Physics.SyncTransforms();
            for (int i = 0; i < 25 && probe.calls.Count == 0; i++) yield return new WaitForFixedUpdate();
            Assert.AreEqual(2, probe.calls.Count);
            Assert.AreSame(target, probe.calls[0].Target);
            Assert.AreSame(target, probe.calls[1].Target);
        }

        [UnityTest]
        public IEnumerator AreaInXYEmitsOnceForCompoundBody()
        {
            if (!Application.isPlaying) Assert.Ignore("Play Mode");
            var settings = Track(ScriptableObject.CreateInstance<MADProjectileDescriptor>());
            settings.areaRadius = 2f;
            var origin = new Vector3(-1000, -1000, 0);
            var target = At("Body", origin + Vector3.right);
            target.AddComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
            target.AddComponent<BoxCollider2D>();
            target.AddComponent<CircleCollider2D>();
            var probe = target.AddComponent<MADProjectileProbe>();
            var shot = At("Shot", origin).AddComponent<MADProjectile>();
            shot.onAreaTarget.SetActions(probe);
            Assert.IsTrue(shot.Launch(settings, MADFlightPlane.XY, Vector3.right, null));
            Physics2D.SyncTransforms();
            shot.Finish(null);
            shot.Finish(null);
            Assert.AreEqual(1, probe.calls.Count);
            Assert.AreSame(target, probe.calls[0].Target);
            yield return null;
        }

        [Test]
        public void ChainVisitsTwoNearestDistinctTargets()
        {
            Vector3 origin = new Vector3(1000, 1000, 1000);
            var settings = Track(ScriptableObject.CreateInstance<MADProjectileDescriptor>());
            settings.chainHops = 2;
            settings.chainRadius = 2f;
            var shot = At("Electric", origin).AddComponent<MADProjectile>();
            Assert.IsTrue(shot.Launch(settings, MADFlightPlane.XZ, Vector3.right, null));
            var first = At("Direct hit", origin);
            var second = At("First link", origin + Vector3.right);
            var third = At("Second link", origin + Vector3.right * 2.5f);
            foreach (var target in new[] { first, second, third }) target.AddComponent<BoxCollider>();
            var chain = shot.gameObject.AddComponent<MADChainTargets>();
            var probe = shot.gameObject.AddComponent<MADProjectileProbe>();
            chain.onLink.SetActions(probe);
            Physics.SyncTransforms();
            chain.Execute(new MADContext(shot.gameObject, first, origin, Vector3.right));
            Assert.AreEqual(2, probe.calls.Count);
            Assert.AreSame(second, probe.calls[0].Target);
            Assert.AreSame(third, probe.calls[1].Target);
        }

        [Test]
        public void LaunchRejectsDirectionPerpendicularToPlane()
        {
            var settings = Track(ScriptableObject.CreateInstance<MADProjectileDescriptor>());
            var shot = At("Shot", Vector3.zero).AddComponent<MADProjectile>();
            Assert.IsFalse(shot.Launch(settings, MADFlightPlane.XY, Vector3.forward, null));
            Assert.IsFalse(shot.InFlight);
        }
    }
}
