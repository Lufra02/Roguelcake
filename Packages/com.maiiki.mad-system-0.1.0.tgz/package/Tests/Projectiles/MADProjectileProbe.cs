using System.Collections.Generic;

namespace Maiiki.MAD.Tests
{
    public sealed class MADProjectileProbe : MADAction
    {
        public List<MADContext> calls = new List<MADContext>();
        public override void Execute(MADContext context) { calls.Add(context); }
    }
}
