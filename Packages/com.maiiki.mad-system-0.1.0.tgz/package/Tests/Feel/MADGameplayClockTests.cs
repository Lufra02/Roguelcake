using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Maiiki.MAD.Tests
{
    public class MADGameplayClockTests
    {
        GameObject root;
        float previous;
        MADGameplayClock clock;
        MADGameplayHitStop one, two;

        [SetUp] public void SetUp()
        {
            previous = Time.timeScale;
            Time.timeScale = 0.75f;
            root = new GameObject("MAD clock fixture");
            clock = root.AddComponent<MADGameplayClock>();
            one = root.AddComponent<MADGameplayHitStop>();
            two = root.AddComponent<MADGameplayHitStop>();
            one.clock = two.clock = clock;
        }

        [TearDown] public void TearDown()
        {
            Object.DestroyImmediate(root);
            Time.timeScale = previous;
        }

        [Test] public void MenuKeepsPauseAfterAllOverlappingHitsFinish()
        {
            one.Execute(null); two.Execute(null);
            Assert.AreEqual(0f, Time.timeScale);
            clock.SetPaused(true);
            one.Cancel(); two.Cancel();
            Assert.AreEqual(0f, Time.timeScale);
            clock.SetPaused(false);
            Assert.AreEqual(0.75f, Time.timeScale);
            Time.timeScale = 0f;
            one.Execute(null); one.Cancel();
            Assert.AreEqual(0f, Time.timeScale);
        }

        [UnityTest] public IEnumerator GameplayResumesUsingUnscaledTime()
        {
            if (!Application.isPlaying) Assert.Ignore("Play Mode");
            one.duration = 0.02f;
            one.Execute(null);
            Assert.AreEqual(0f, Time.timeScale);
            yield return new WaitForSecondsRealtime(0.08f);
            yield return null;
            Assert.AreEqual(0.75f, Time.timeScale);
        }
    }
}
