using NUnit.Framework;
using UnityEngine;

namespace Maiiki.MAD.Tests
{
    public sealed class MADFeelTests
    {
        [Test]
        public void ReplayAndDisableRestoreVisualScale()
        {
            var host = new GameObject("MAD visual test");
            try
            {
                var visual = new GameObject("pivot");
                visual.transform.SetParent(host.transform);
                var rest = new Vector3(2f, 1.2f, 0.5f);
                visual.transform.localScale = rest;
                var pulse = host.AddComponent<MADVisualPulse>();
                pulse.style = MADVisualPulse.Style.SquashStretch;
                pulse.pivot = visual.transform;
                pulse.Execute(null);
                var first = visual.transform.localScale;
                Assert.AreNotEqual(rest, first);
                pulse.Execute(null);
                Assert.AreEqual(first, visual.transform.localScale);
                pulse.enabled = false;
                Assert.AreEqual(rest, visual.transform.localScale);
                Assert.AreEqual(Vector3.one, host.transform.localScale);
            }
            finally { Object.DestroyImmediate(host); }
        }

        [Test]
        public void PerspectiveKickRestoresFovAndSkipsOrthographicCamera()
        {
            var host = new GameObject("MAD camera test");
            try
            {
                var cam = host.AddComponent<Camera>();
                cam.fieldOfView = 65f;
                var pulse = host.AddComponent<MADFieldOfViewPulse>();
                pulse.targetCamera = cam;
                pulse.degrees = 3f;
                pulse.Execute(null);
                Assert.That(cam.fieldOfView, Is.EqualTo(68f).Within(0.001f));
                pulse.StopEffect();
                Assert.That(cam.fieldOfView, Is.EqualTo(65f).Within(0.001f));
                cam.orthographic = true;
                pulse.Execute(null);
                Assert.That(cam.fieldOfView, Is.EqualTo(65f).Within(0.001f));
            }
            finally { Object.DestroyImmediate(host); }
        }
    }
}
