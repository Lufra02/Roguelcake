using UnityEngine;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Feel/Gameplay Hit Stop")]
    public sealed class MADGameplayHitStop : MADAction
    {
        public MADGameplayClock clock;
        [Min(0f)] public float duration = 0.065f;
        private MADGameplayClock heldClock;
        private double until;

        public override void Execute(MADContext context)
        {
            if (!isActiveAndEnabled || duration <= 0f || !clock) return;
            if (heldClock != clock) Cancel();
            if (!clock.AcquireHit(this)) return;
            heldClock = clock;
            until = Time.realtimeSinceStartupAsDouble + duration;
        }

        private void Update()
        {
            if (heldClock && Time.realtimeSinceStartupAsDouble >= until) Cancel();
        }

        public void Cancel()
        {
            if (heldClock) heldClock.ReleaseHit(this);
            heldClock = null;
        }

        private void OnDisable() => Cancel();
    }
}
