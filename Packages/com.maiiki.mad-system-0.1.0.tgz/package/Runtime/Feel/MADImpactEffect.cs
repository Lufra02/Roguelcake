using System.Collections.Generic;
using UnityEngine;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Feel/Spawn Impact or World Effect")]
    public sealed class MADImpactEffect : MADAction
    {
        [Tooltip("Use a decorative prefab. Unity destroys each instance after its lifetime in game seconds.")]
        public GameObject effectPrefab;
        [Min(0.01f)] public float lifetime = 1f;
        [Min(1)] public int maxActive = 8;
        private readonly List<GameObject> instances = new List<GameObject>();

        public override void Execute(MADContext context)
        {
            if (!isActiveAndEnabled || !effectPrefab || context == null) return;
            instances.RemoveAll(item => !item);
            if (instances.Count >= maxActive) return;
            Vector3 forward = context.Direction;
            Quaternion facing = forward.sqrMagnitude > 0.0001f
                ? Quaternion.FromToRotation(Vector3.forward, forward.normalized) : Quaternion.identity;
            GameObject instance = Instantiate(effectPrefab, context.Position, facing);
            instances.Add(instance);
            Destroy(instance, Mathf.Max(0.01f, lifetime));
        }
    }
}
