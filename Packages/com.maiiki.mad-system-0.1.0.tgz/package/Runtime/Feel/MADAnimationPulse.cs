using UnityEngine;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Feel/Animation Speed or Hit Stop")]
    public sealed class MADAnimationPulse : MADTimedAction
    {
        public Animator visualAnimator;
        public bool hitStop;
        public AnimationCurve speedMultiplier = new AnimationCurve(
            new Keyframe(0f, 0.3f), new Keyframe(0.4f, 1.8f), new Keyframe(1f, 1f));
        private Animator activeAnimator;
        private float previousSpeed;

        protected override bool Begin(MADContext context)
        {
            if (!visualAnimator) return false;
            activeAnimator = visualAnimator;
            previousSpeed = activeAnimator.speed;
            return true;
        }

        protected override void Apply(float phase)
        {
            if (activeAnimator) activeAnimator.speed = hitStop ? 0f : previousSpeed * Mathf.Max(0f, speedMultiplier.Evaluate(phase));
        }

        protected override void Restore()
        {
            if (activeAnimator) activeAnimator.speed = previousSpeed;
        }
    }
}
