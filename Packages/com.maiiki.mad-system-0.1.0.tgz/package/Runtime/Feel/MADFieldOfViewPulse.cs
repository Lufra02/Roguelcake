using UnityEngine;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Feel/Field Of View Kick")]
    public sealed class MADFieldOfViewPulse : MADTimedAction
    {
        public Camera targetCamera;
        [Range(-30f, 30f)] public float degrees = 3f;
        private Camera activeCamera;
        private float previousFov;
        protected override bool Begin(MADContext context)
        {
            if (!targetCamera || targetCamera.orthographic || degrees == 0f) return false;
            activeCamera = targetCamera;
            previousFov = targetCamera.fieldOfView;
            return true;
        }
        protected override void Apply(float phase)
        {
            if (activeCamera) activeCamera.fieldOfView = Mathf.Clamp(previousFov + degrees * (1f - phase), 1f, 179f);
        }
        protected override void Restore()
        {
            if (activeCamera) activeCamera.fieldOfView = previousFov;
        }
    }
}
