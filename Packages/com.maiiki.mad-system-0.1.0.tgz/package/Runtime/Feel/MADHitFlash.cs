using UnityEngine;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Feel/Hit Flash")]
    public sealed class MADHitFlash : MADTimedAction
    {
        public SpriteRenderer sprite;
        [Tooltip("Optional 3D flash mesh with its own material; it follows the character.")]
        public Renderer overlay;
        public Color flashColor = Color.white;
        [Range(0f, 1f)] public float intensity = 1f;
        private SpriteRenderer activeSprite;
        private Renderer activeOverlay;
        private Color previousColor;
        private bool previousVisibility;

        protected override bool Begin(MADContext context)
        {
            if ((!sprite && !overlay) || intensity <= 0f) return false;
            activeSprite = sprite;
            activeOverlay = overlay;
            if (sprite) previousColor = sprite.color;
            if (overlay) previousVisibility = overlay.enabled;
            return true;
        }

        protected override void Apply(float phase)
        {
            if (activeSprite) activeSprite.color = Color.Lerp(previousColor, flashColor, intensity * (1f - phase));
            if (activeOverlay) activeOverlay.enabled = true;
        }

        protected override void Restore()
        {
            if (activeSprite) activeSprite.color = previousColor;
            if (activeOverlay) activeOverlay.enabled = previousVisibility;
        }
    }
}
