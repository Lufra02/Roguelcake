using UnityEngine;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Feel/Trail Window")]
    public sealed class MADTrailWindow : MADTimedAction
    {
        public TrailRenderer trail;
        private TrailRenderer activeTrail;
        private bool wasEmitting;
        protected override bool Begin(MADContext context)
        {
            if (!trail) return false;
            activeTrail = trail;
            wasEmitting = trail.emitting;
            return true;
        }
        protected override void Apply(float phase)
        {
            if (activeTrail) activeTrail.emitting = true;
        }
        protected override void Restore()
        {
            if (activeTrail) activeTrail.emitting = wasEmitting;
        }
    }
}
