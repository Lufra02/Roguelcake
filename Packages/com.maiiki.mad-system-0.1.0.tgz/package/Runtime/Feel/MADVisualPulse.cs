using UnityEngine;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Feel/Visual Pulse")]
    public sealed class MADVisualPulse : MADTimedAction
    {
        public enum Style { Anticipation, SquashStretch, HitReaction, FollowThrough, MotionSmear, SecondaryMotion, CameraShake }
        public Style style;
        [Tooltip("Dedicated visual pivot, below the physics, animation or camera controller.")]
        public Transform pivot;
        public Vector3 axis = Vector3.right;
        [Min(0f)] public float amplitude = 0.15f;
        [Min(0f)] public float cycles = 3f;
        private Vector3 position;
        private Vector3 scale;
        private Quaternion rotation;
        private Vector3 direction;
        private Transform activePivot;
        private Style activeStyle;

        protected override bool Begin(MADContext context)
        {
            if (!pivot || amplitude <= 0f) return false;
            activePivot = pivot;
            activeStyle = style;
            position = pivot.localPosition;
            scale = pivot.localScale;
            rotation = pivot.localRotation;
            direction = axis.normalized;
            if (style == Style.HitReaction && context != null && context.Direction.sqrMagnitude > 0f)
                direction = pivot.parent ? pivot.parent.InverseTransformDirection(context.Direction).normalized : context.Direction.normalized;
            return true;
        }

        protected override void Apply(float phase)
        {
            if (!activePivot) return;
            float decay = 1f - phase;
            float arc = Mathf.Sin(phase * Mathf.PI);
            float wave = Mathf.Cos(phase * cycles * Mathf.PI * 2f) * decay * decay;
            switch (activeStyle)
            {
                case Style.SquashStretch:
                case Style.MotionSmear:
                    // The configured axis chooses elongation; compress transverse axes.
                    Vector3 weights = new Vector3(Mathf.Abs(direction.x), Mathf.Abs(direction.y), Mathf.Abs(direction.z));
                    float length = 1f + amplitude * decay;
                    Vector3 transverse = Vector3.one / Mathf.Sqrt(length);
                    Vector3 multiplier = transverse + Vector3.Scale(Vector3.one * length - transverse, weights);
                    activePivot.localScale = Vector3.Scale(scale, multiplier);
                    break;
                case Style.SecondaryMotion:
                    activePivot.localRotation = Quaternion.AngleAxis(amplitude * wave, direction) * rotation;
                    break;
                case Style.CameraShake:
                case Style.FollowThrough:
                    activePivot.localPosition = position + direction * (amplitude * wave);
                    break;
                case Style.Anticipation:
                    activePivot.localPosition = position - direction * (amplitude * arc);
                    break;
                case Style.HitReaction:
                    activePivot.localPosition = position + direction * (amplitude * decay * decay);
                    break;
            }
        }

        protected override void Restore()
        {
            if (!activePivot) return;
            if (activeStyle == Style.SquashStretch || activeStyle == Style.MotionSmear) activePivot.localScale = scale;
            else if (activeStyle == Style.SecondaryMotion) activePivot.localRotation = rotation;
            else activePivot.localPosition = position;
        }
    }
}
