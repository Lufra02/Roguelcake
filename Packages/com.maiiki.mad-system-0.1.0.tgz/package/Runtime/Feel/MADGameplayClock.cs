using System.Collections.Generic;
using UnityEngine;

namespace Maiiki.MAD
{
    /// <summary>Shared authority for hit stops and the host's pause menu. One owner writes global time.</summary>
    [DisallowMultipleComponent]
    public sealed class MADGameplayClock : MonoBehaviour
    {
        private static MADGameplayClock owner;
        private readonly HashSet<MADGameplayHitStop> requests = new HashSet<MADGameplayHitStop>();
        private float resumeScale;
        private bool paused;

        private bool Acquire()
        {
            if (!isActiveAndEnabled || (owner && owner != this)) return false;
            if (owner == this) return true;
            // A host that already owns a paused world retains its pause.
            if (Time.timeScale <= 0f) return false;
            owner = this;
            resumeScale = Time.timeScale;
            Time.timeScale = 0f;
            return true;
        }

        internal bool AcquireHit(MADGameplayHitStop source)
        {
            if (!Acquire()) return false;
            requests.Add(source);
            return true;
        }

        internal void ReleaseHit(MADGameplayHitStop source)
        {
            requests.Remove(source);
            ReleaseIfIdle();
        }

        public void SetPaused(bool value)
        {
            if (value && !Acquire()) return;
            paused = value;
            ReleaseIfIdle();
        }

        private void ReleaseIfIdle()
        {
            if (owner != this || paused || requests.Count > 0) return;
            if (Time.timeScale == 0f) Time.timeScale = resumeScale;
            owner = null;
        }

        private void OnDisable()
        {
            paused = false;
            requests.Clear();
            ReleaseIfIdle();
        }
    }
}
