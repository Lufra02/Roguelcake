using UnityEngine;

namespace Maiiki.MAD
{
    /// <summary>One active pulse per action. Restore owned presentation state on replay or disable.</summary>
    public abstract class MADTimedAction : MADAction
    {
        [Min(0.001f)] public float duration = 0.16f;
        public bool unscaledTime = true;
        private bool playing;
        private float elapsed;

        public sealed override void Execute(MADContext context)
        {
            StopEffect();
            if (!isActiveAndEnabled || duration <= 0f || !Begin(context)) return;
            playing = true;
            elapsed = 0f;
            Apply(0f);
        }

        protected virtual void LateUpdate()
        {
            if (!playing) return;
            elapsed += unscaledTime ? Time.unscaledDeltaTime : Time.deltaTime;
            if (elapsed >= duration) StopEffect();
            else Apply(elapsed / duration);
        }

        public void StopEffect()
        {
            if (!playing) return;
            playing = false;
            Restore();
        }

        protected virtual void OnDisable() => StopEffect();
        protected abstract bool Begin(MADContext context);
        protected abstract void Apply(float phase);
        protected abstract void Restore();
    }
}
