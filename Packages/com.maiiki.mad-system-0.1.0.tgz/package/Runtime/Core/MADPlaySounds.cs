using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Actions/Play Sounds")]
    public sealed class MADPlaySounds : MADAction
    {
        [SerializeField] private AudioClip[] clips = System.Array.Empty<AudioClip>();
        [SerializeField] private Vector2 volumeRange = Vector2.one;
        [SerializeField] private Vector2 pitchRange = Vector2.one;
        [SerializeField, Range(0f, 1f)] private float spatialBlend;
        [SerializeField] private AudioMixerGroup output;

        // Each voice owns its pitch. Overlapping impacts and source destruction cannot cut it off.
        public override void Execute(MADContext context)
        {
            if (clips.Length == 0) return;
            var clip = clips[Random.Range(0, clips.Length)];
            if (!clip) return;

            var voice = new GameObject("MAD Sound - " + clip.name);
            if (gameObject.scene.IsValid() && gameObject.scene.isLoaded)
                SceneManager.MoveGameObjectToScene(voice, gameObject.scene);
            voice.transform.position = context.Position;
            var source = voice.AddComponent<AudioSource>();
            source.playOnAwake = false;
            source.clip = clip;
            source.outputAudioMixerGroup = output;
            source.spatialBlend = spatialBlend;
            source.volume = SampleRange(volumeRange, 0f, 1f);
            source.pitch = SampleRange(pitchRange, 0.01f, 3f);
            source.Play();
            voice.AddComponent<MADSoundLifetime>();
        }

        internal static float SampleRange(Vector2 range, float minimum, float maximum)
        {
            float low = Mathf.Clamp(Mathf.Min(range.x, range.y), minimum, maximum);
            float high = Mathf.Clamp(Mathf.Max(range.x, range.y), minimum, maximum);
            return Random.Range(low, high);
        }
    }
}
