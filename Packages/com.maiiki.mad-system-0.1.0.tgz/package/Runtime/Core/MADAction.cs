using UnityEngine;

namespace Maiiki.MAD
{
    public abstract class MADAction : MonoBehaviour
    {
        public abstract void Execute(MADContext context);
    }
}
