using UnityEngine;

namespace Maiiki.MAD
{
    /// <summary>World-space snapshot of one occurrence. Target can be null.</summary>
    public sealed class MADContext
    {
        public GameObject Source { get; }
        public GameObject Target { get; }
        public Vector3 Position { get; }
        public Vector3 Direction { get; }

        public MADContext(GameObject source, GameObject target, Vector3 position, Vector3 direction)
        {
            Source = source;
            Target = target;
            Position = position;
            Direction = direction;
        }
    }
}
