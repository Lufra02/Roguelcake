using UnityEngine;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Events/Event Emitter")]
    public sealed class MADEventEmitter : MonoBehaviour
    {
        [SerializeField] private MADEvent onEmit = new MADEvent();
        public MADEvent OnEmit => onEmit;

        public void Emit() => EmitTo(null);

        public void EmitTo(GameObject target)
        {
            if (!isActiveAndEnabled) return;
            var direction = target ? (target.transform.position - transform.position).normalized : transform.forward;
            onEmit.Raise(new MADContext(gameObject, target, transform.position, direction));
        }
    }
}
