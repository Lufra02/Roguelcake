using System;
using UnityEngine;

namespace Maiiki.MAD
{
    [Serializable]
    public sealed class MADEvent
    {
        [SerializeField] private MADAction[] actions = Array.Empty<MADAction>();
        [NonSerialized] private bool dispatching;

        public void SetActions(params MADAction[] orderedActions)
        {
            actions = orderedActions == null ? Array.Empty<MADAction>() : (MADAction[])orderedActions.Clone();
        }

        public void Raise(MADContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));
            // Cyclic Inspector wiring cannot recursively dispatch this same signal.
            if (dispatching) return;
            dispatching = true;
            try
            {
                foreach (var action in actions)
                {
                    if (action && action.isActiveAndEnabled) action.Execute(context);
                }
            }
            finally
            {
                dispatching = false;
            }
        }
    }
}
