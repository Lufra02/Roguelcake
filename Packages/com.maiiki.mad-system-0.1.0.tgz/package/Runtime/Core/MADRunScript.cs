using System;
using UnityEngine;
using UnityEngine.Events;

namespace Maiiki.MAD
{
    [Serializable] public sealed class MADScriptCallback : UnityEvent<MADContext> { }

    [AddComponentMenu("MAD/Actions/Run Script")]
    public sealed class MADRunScript : MADAction
    {
        [SerializeField] private MADScriptCallback callback = new MADScriptCallback();
        public MADScriptCallback Callback => callback;
        public override void Execute(MADContext context) => callback.Invoke(context);
    }
}
