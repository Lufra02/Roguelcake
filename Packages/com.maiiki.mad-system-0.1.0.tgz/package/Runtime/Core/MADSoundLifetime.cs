using UnityEngine;

namespace Maiiki.MAD
{
    [AddComponentMenu("")]
    public sealed class MADSoundLifetime : MonoBehaviour
    {
        private AudioSource voice;
        private void Awake() => voice = GetComponent<AudioSource>();
        private void Update()
        {
            if (!AudioListener.pause && (!voice || !voice.isPlaying)) Destroy(gameObject);
        }
    }
}
