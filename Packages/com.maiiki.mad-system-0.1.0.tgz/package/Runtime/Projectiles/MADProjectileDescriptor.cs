using UnityEngine;

namespace Maiiki.MAD
{
    public enum MADTrajectory { Straight, Parabolic, Sine, Zigzag }
    public enum MADFlightPlane { XZ, XY }

    [CreateAssetMenu(menuName = "MAD/Projectile/Descriptor")]
    public sealed class MADProjectileDescriptor : ScriptableObject
    {
        public MADTrajectory trajectory;
        [Min(0.01f)] public float speed = 10f;
        [Min(0.01f)] public float lifetime = 10f;
        [Min(0.01f)] public float travelInterval = 0.5f;
        [Min(0f)] public float arcHeight = 3f;
        [Min(0f)] public float waveWidth = 1f;
        [Min(0f)] public float waveFrequency = 1f;
        [Min(0)] public int bounces;
        [Range(1, 64)] public int radialCount = 1;
        [Min(0f)] public float areaRadius;
        [Min(0f)] public float areaImpulse;
        [Range(0, 8)] public int chainHops;
        [Min(0f)] public float chainRadius = 3f;
    }
}
