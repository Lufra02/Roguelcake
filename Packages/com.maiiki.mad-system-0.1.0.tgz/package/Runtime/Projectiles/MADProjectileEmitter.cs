using UnityEngine;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Projectile/MAD Projectile Emitter")]
    public sealed class MADProjectileEmitter : MonoBehaviour
    {
        public MADProjectile prefab;
        public MADProjectileDescriptor descriptor;
        public MADFlightPlane plane;
        public Transform muzzle;
        public GameObject owner;
        public bool autoFire;
        [Min(0.01f)] public float interval = 0.5f;
        float remaining;

        void Update()
        {
            if (!autoFire || Time.deltaTime <= 0f) return;
            remaining -= Time.deltaTime;
            if (remaining > 0) return;
            remaining = Mathf.Max(0.01f, interval);
            FireForward();
        }

        public void FireForward()
        {
            Transform origin = muzzle ? muzzle : transform;
            Fire(plane == MADFlightPlane.XY ? origin.up : origin.forward);
        }

        public int Fire(Vector3 direction)
        {
            if (!prefab || !descriptor) return 0;
            Vector3 axis = plane == MADFlightPlane.XY ? Vector3.forward : Vector3.up;
            Vector3 heading = Vector3.ProjectOnPlane(direction, axis).normalized;
            if (heading == Vector3.zero) return 0;
            Vector3 origin = muzzle ? muzzle.position : transform.position;
            int count = Mathf.Clamp(descriptor.radialCount, 1, 64);
            for (int i = 0; i < count; i++)
            {
                Vector3 ray = Quaternion.AngleAxis(i * 360f / count, axis) * heading;
                Quaternion rotation = plane == MADFlightPlane.XY ? Quaternion.LookRotation(Vector3.forward, ray) : Quaternion.LookRotation(ray);
                var instance = Instantiate(prefab, origin, rotation);
                instance.gameObject.SetActive(true);
                instance.Launch(descriptor, plane, ray, owner ? owner : gameObject);
            }
            return count;
        }
    }
}
