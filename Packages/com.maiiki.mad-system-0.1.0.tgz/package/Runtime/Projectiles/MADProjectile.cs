using System.Collections.Generic;
using UnityEngine;

namespace Maiiki.MAD
{
    // Attach visuals as children. Swept queries need colliders only on targets.
    [AddComponentMenu("MAD/Projectile/MAD Projectile")]
    public sealed class MADProjectile : MonoBehaviour
    {
        public MADProjectileDescriptor descriptor;
        public MADFlightPlane plane;
        public LayerMask targetLayers = ~0;
        public MADEvent onSpawn = new MADEvent();
        public MADEvent whileTraveling = new MADEvent();
        public MADEvent onImpact = new MADEvent();
        public MADEvent onBounce = new MADEvent();
        public MADEvent onAreaTarget = new MADEvent();
        public MADEvent onEnd = new MADEvent();

        public GameObject Owner { get; private set; }
        public bool InFlight { get; private set; }
        bool launched;
        int bounces;
        float age, nextTick, legAge;
        Vector3 heading;
        public Vector3 FlightDirection => heading;
        Vector3 Up => plane == MADFlightPlane.XY ? Vector3.forward : Vector3.up;

        void Start()
        {
            if (!launched && descriptor)
                Launch(descriptor, plane, plane == MADFlightPlane.XY ? transform.up : transform.forward, null);
        }

        public bool Launch(MADProjectileDescriptor settings, MADFlightPlane flightPlane, Vector3 direction, GameObject owner)
        {
            if (launched || !settings) return false;
            plane = flightPlane;
            heading = Vector3.ProjectOnPlane(direction, Up).normalized;
            if (heading == Vector3.zero) return false;
            descriptor = settings;
            Owner = owner;
            nextTick = Mathf.Max(0.01f, descriptor.travelInterval);
            launched = InFlight = true;
            onSpawn.Raise(Context(null));
            return true;
        }

        MADContext Context(GameObject target) => new MADContext(gameObject, target, transform.position, heading);

        float Offset(float time)
        {
            switch (descriptor.trajectory)
            {
                case MADTrajectory.Parabolic:
                    float t = Mathf.Clamp01(time / Mathf.Max(0.01f, descriptor.lifetime));
                    return 4f * t * (1f - t) * descriptor.arcHeight;
                case MADTrajectory.Sine:
                    return Mathf.Sin(time * descriptor.waveFrequency * 2f * Mathf.PI) * descriptor.waveWidth;
                case MADTrajectory.Zigzag:
                    return (Mathf.PingPong(time * descriptor.waveFrequency * 4f + 1f, 2f) - 1f) * descriptor.waveWidth;
                default: return 0f;
            }
        }

        void FixedUpdate()
        {
            if (!InFlight) return;
            float step = Mathf.Min(Time.fixedDeltaTime, Mathf.Max(0f, descriptor.lifetime - age));
            Vector3 side = Vector3.Cross(Up, heading);
            if (descriptor.trajectory == MADTrajectory.Parabolic)
                side = Vector3.up;
            Vector3 move = heading * (step * descriptor.speed) + side * (Offset(legAge + step) - Offset(legAge));
            age += step;
            legAge += step;
            if (FindHit(move, out var target, out var point, out var normal))
            {
                transform.position = point;
                onImpact.Raise(Context(target));
                if (!InFlight) return;
                if (bounces >= descriptor.bounces)
                {
                    Finish(target);
                    return;
                }
                Vector3 reflected = Vector3.ProjectOnPlane(Vector3.Reflect(move.normalized, normal), Up).normalized;
                if (reflected == Vector3.zero) { Finish(target); return; }
                heading = reflected;
                bounces++;
                legAge = 0f;
                transform.position += normal * 0.001f;
                onBounce.Raise(Context(target));
                if (!InFlight) return;
            }
            else transform.position += move;
            if (age >= nextTick)
            {
                nextTick += Mathf.Max(0.01f, descriptor.travelInterval);
                whileTraveling.Raise(Context(null));
            }
            if (age >= descriptor.lifetime) Finish(null);
        }

        bool Accept(Transform candidate)
        {
            return candidate && !candidate.GetComponentInParent<MADProjectile>() &&
                (!Owner || !candidate.IsChildOf(Owner.transform));
        }

        bool FindHit(Vector3 move, out GameObject target, out Vector3 point, out Vector3 normal)
        {
            target = null;
            point = normal = Vector3.zero;
            float distance = move.magnitude;
            if (distance <= Mathf.Epsilon) return false;
            if (plane == MADFlightPlane.XY)
            {
                // Unity orders 2D results by distance. Global queriesHitTriggers applies.
                foreach (var hit in Physics2D.RaycastAll(transform.position, move / distance, distance, targetLayers))
                {
                    if (!Accept(hit.collider.transform)) continue;
                    target = hit.rigidbody ? hit.rigidbody.gameObject : hit.collider.gameObject;
                    point = new Vector3(hit.point.x, hit.point.y, transform.position.z);
                    normal = hit.normal;
                    return true;
                }
            }
            else
            {
                float nearest = float.PositiveInfinity;
                foreach (var hit in Physics.RaycastAll(transform.position, move / distance, distance, targetLayers, QueryTriggerInteraction.Collide))
                {
                    if (hit.distance >= nearest || !Accept(hit.collider.transform)) continue;
                    nearest = hit.distance;
                    target = hit.rigidbody ? hit.rigidbody.gameObject : hit.collider.gameObject;
                    point = hit.point;
                    normal = hit.normal;
                }
            }
            return target;
        }

        // Logical end is emitted once for impact, expiry or explicit termination.
        public void Finish(GameObject target)
        {
            if (!InFlight) return;
            InFlight = false;
            try
            {
                ApplyArea();
                onEnd.Raise(Context(target));
            }
            finally { Destroy(gameObject); }
        }

        void ApplyArea()
        {
            if (descriptor.areaRadius <= 0) return;
            var seen = new HashSet<GameObject>();
            if (plane == MADFlightPlane.XY)
            {
                foreach (var collider in Physics2D.OverlapCircleAll(transform.position, descriptor.areaRadius, targetLayers))
                {
                    if (!collider || !Accept(collider.transform)) continue;
                    var body = collider.attachedRigidbody;
                    var target = body ? body.gameObject : collider.gameObject;
                    if (!seen.Add(target)) continue;
                    if (body && descriptor.areaImpulse > 0)
                        body.AddForce(((Vector2)(body.transform.position - transform.position)).normalized * descriptor.areaImpulse, ForceMode2D.Impulse);
                    onAreaTarget.Raise(Context(target));
                }
            }
            else
            {
                foreach (var collider in Physics.OverlapSphere(transform.position, descriptor.areaRadius, targetLayers, QueryTriggerInteraction.Collide))
                {
                    if (!collider || !Accept(collider.transform)) continue;
                    var body = collider.attachedRigidbody;
                    var target = body ? body.gameObject : collider.gameObject;
                    if (!seen.Add(target)) continue;
                    if (body && descriptor.areaImpulse > 0)
                        body.AddForce((body.position - transform.position).normalized * descriptor.areaImpulse, ForceMode.Impulse);
                    onAreaTarget.Raise(Context(target));
                }
            }
        }
    }
}
