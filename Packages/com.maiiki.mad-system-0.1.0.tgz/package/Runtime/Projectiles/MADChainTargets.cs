using System.Collections.Generic;
using UnityEngine;

namespace Maiiki.MAD
{
    // Wire to onImpact. The game subscribes its own status/damage action to onLink.
    public sealed class MADChainTargets : MADAction
    {
        public MADEvent onLink = new MADEvent();

        public override void Execute(MADContext context)
        {
            if (!context.Target || !context.Source ||
                !context.Source.TryGetComponent<MADProjectile>(out var shot)) return;
            var settings = shot.descriptor;
            if (!settings || settings.chainHops <= 0 || settings.chainRadius <= 0) return;
            var visited = new HashSet<GameObject> { context.Target };
            var previous = context.Target;
            for (int hop = 0; hop < Mathf.Min(8, settings.chainHops); hop++)
            {
                if (!previous) break;
                Vector3 origin = previous.transform.position;
                GameObject next = null;
                float nearest = float.PositiveInfinity;

                void Consider(GameObject candidate)
                {
                    if (!candidate || visited.Contains(candidate) ||
                        candidate.GetComponentInParent<MADProjectile>() ||
                        (shot.Owner && candidate.transform.IsChildOf(shot.Owner.transform))) return;
                    float distance = (candidate.transform.position - origin).sqrMagnitude;
                    if (distance >= nearest) return;
                    nearest = distance;
                    next = candidate;
                }

                if (shot.plane == MADFlightPlane.XY)
                {
                    foreach (var collider in Physics2D.OverlapCircleAll(origin, settings.chainRadius, shot.targetLayers))
                        Consider(collider.attachedRigidbody ? collider.attachedRigidbody.gameObject : collider.gameObject);
                }
                else
                {
                    foreach (var collider in Physics.OverlapSphere(origin, settings.chainRadius, shot.targetLayers, QueryTriggerInteraction.Collide))
                        Consider(collider.attachedRigidbody ? collider.attachedRigidbody.gameObject : collider.gameObject);
                }
                if (!next) break;
                visited.Add(next);
                Vector3 point = next.transform.position;
                onLink.Raise(new MADContext(shot.gameObject, next, point, (point - origin).normalized));
                previous = next;
            }
        }
    }
}
