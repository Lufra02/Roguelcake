namespace Maiiki.MAD
{
    public enum MADMovementPlane { XYZ, XY, XZ }
}