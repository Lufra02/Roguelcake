using UnityEngine;

namespace Maiiki.MAD
{
    /// <summary>Shared actor lifecycle and movement intent. Its motor and health owner are selectable.</summary>
    [DisallowMultipleComponent]
    [AddComponentMenu("MAD/Character/Character")]
    public class MADCharacter : MonoBehaviour
    {
        [SerializeField, Min(0f)] private float maximumSpeed = 6f;
        [Tooltip("Enable only for characters that have per-frame actions.")]
        [SerializeField] private bool emitTick;
        [SerializeField] private MADEvent onSpawn = new MADEvent();
        [SerializeField] private MADEvent onHit = new MADEvent();
        [SerializeField] private MADEvent onDeath = new MADEvent();
        [SerializeField] private MADEvent onInteraction = new MADEvent();
        [SerializeField] private MADEvent onImpact = new MADEvent();
        [SerializeField] private MADEvent onStateChanged = new MADEvent();
        [SerializeField] private MADEvent onTick = new MADEvent();

        public MADEvent OnSpawn => onSpawn;
        public MADEvent OnHit => onHit;
        public MADEvent OnDeath => onDeath;
        public MADEvent OnInteraction => onInteraction;
        public MADEvent OnImpact => onImpact;
        public MADEvent OnStateChanged => onStateChanged;
        public MADEvent OnTick => onTick;
        public bool EmitTick { get => emitTick; set => emitTick = value; }
        private bool spawnPending;
        public bool IsDead { get; private set; }
        public bool CanAct => isActiveAndEnabled && !IsDead;
        public string CurrentState { get; private set; } = string.Empty;
        public Vector3 DesiredVelocity { get; private set; }

        protected virtual void OnEnable()
        {
            IsDead = false;
            DesiredVelocity = Vector3.zero;
            CurrentState = string.Empty;
            spawnPending = true;
        }

        protected virtual void OnDisable()
        {
            spawnPending = false;
            DesiredVelocity = Vector3.zero;
        }

        // Unity can enable this component before the actions on the same pooled object.
        // Deliver its spawn after activation, before the first tick or explicit gameplay event.
        private void DispatchSpawn()
        {
            if (!spawnPending || !isActiveAndEnabled) return;
            spawnPending = false;
            onSpawn.Raise(Context(null));
        }

        protected virtual void Update()
        {
            DispatchSpawn();
            if (emitTick && CanAct) onTick.Raise(Context(null));
        }

        // Units per second, independent of the caller's time step or input provider.
        public virtual void SetDesiredVelocity(Vector3 velocity)
        {
            DesiredVelocity = CanAct ? Vector3.ClampMagnitude(velocity, Mathf.Max(0f, maximumSpeed)) : Vector3.zero;
        }

        public void ChangeState(string state)
        {
            DispatchSpawn();
            state = state ?? string.Empty;
            if (!CanAct || CurrentState == state) return;
            CurrentState = state;
            onStateChanged.Raise(Context(null));
        }

        // External controllers may keep full authority over collision, health and pooling.
        public void NotifyHit(GameObject other)
        {
            DispatchSpawn();
            if (CanAct) onHit.Raise(Context(other));
        }

        public void NotifyImpact(GameObject other, Vector3 point, Vector3 normal)
        {
            DispatchSpawn();
            if (CanAct) onImpact.Raise(new MADContext(gameObject, other, point, normal));
        }

        public void NotifyDeath(GameObject other)
        {
            DispatchSpawn();
            if (!CanAct) return;
            IsDead = true;
            DesiredVelocity = Vector3.zero;
            onDeath.Raise(Context(other));
        }

        public void NotifyInteraction(GameObject other)
        {
            DispatchSpawn();
            if (CanAct) onInteraction.Raise(Context(other));
        }

        private MADContext Context(GameObject other)
        {
            var direction = other ? (other.transform.position - transform.position).normalized : Vector3.zero;
            return new MADContext(gameObject, other, transform.position, direction);
        }
    }
}

