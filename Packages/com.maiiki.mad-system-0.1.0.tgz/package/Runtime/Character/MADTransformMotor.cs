using UnityEngine;

namespace Maiiki.MAD
{
    /// <summary>Optional direct movement for unobstructed actors. Physics and navigation controllers can consume DesiredVelocity instead.</summary>
    [RequireComponent(typeof(MADCharacter)), DisallowMultipleComponent, DefaultExecutionOrder(100)]
    [AddComponentMenu("MAD/Character/Transform Motor")]
    public sealed class MADTransformMotor : MonoBehaviour
    {
        private MADCharacter character;
        private void Awake() => character = GetComponent<MADCharacter>();
        private void LateUpdate()
        {
            if (character.CanAct) transform.position += character.DesiredVelocity * Time.deltaTime;
        }
    }
}

