using UnityEngine;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Steering/Flee")]
    public sealed class MADFlee : MonoBehaviour
    {

        [SerializeField] private Transform threat;
        [SerializeField] private MADMovementPlane plane;
        [SerializeField, Min(0f)] private float speed = 3f;
        [SerializeField, Min(0f)] private float detectionDistance = 5f;

        public Transform Threat { get => threat; set => threat = value; }
        public float DetectionDistance { get => detectionDistance; set => detectionDistance = Mathf.Max(0f, value); }

        // The game's existing controller reads this when it owns movement or physics.
        public Vector3 DesiredVelocity
        {
            get
            {
                if (!threat || !isActiveAndEnabled) return Vector3.zero;
                var away = transform.position - threat.position;
                if (plane == MADMovementPlane.XY) away.z = 0;
                if (plane == MADMovementPlane.XZ) away.y = 0;
                if (away.sqrMagnitude > detectionDistance * detectionDistance) return Vector3.zero;
                // A deterministic escape direction also works at coincident positions.
                if (away.sqrMagnitude < 0.000001f) away = Vector3.right;
                return away.normalized * Mathf.Max(0f, speed);
            }
        }
    }
}
