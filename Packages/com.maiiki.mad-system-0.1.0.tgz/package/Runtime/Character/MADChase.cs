using UnityEngine;

namespace Maiiki.MAD
{
    [AddComponentMenu("MAD/Steering/Chase")]
    public sealed class MADChase : MonoBehaviour
    {

        [SerializeField] private Transform target;
        [SerializeField, Min(0)] private float speed = 3f;
        [SerializeField, Min(0)] private float arrivalDistance = 0.25f;
        [SerializeField] private MADMovementPlane plane;
        [Tooltip("Enable only when Chase owns the Transform. Otherwise consume DesiredVelocity in your motor.")]
        [SerializeField] private bool moveTransform;
        [SerializeField] private MADEvent onArrive = new MADEvent();
        private Transform observedTarget;
        private bool inside;
        public Vector3 DesiredVelocity { get; private set; }
        public MADEvent OnArrive => onArrive;
        public Transform Target { get => target; set => target = value; }
        public float ArrivalDistance { get => arrivalDistance; set => arrivalDistance = Mathf.Max(0f, value); }
        public bool MoveTransform { get => moveTransform; set => moveTransform = value; }

        private void Update() => Step(Time.deltaTime);

        private void OnDisable()
        {
            inside = false;
            observedTarget = null;
            DesiredVelocity = Vector3.zero;
        }

        public void Step(float seconds)
        {
            DesiredVelocity = Vector3.zero;
            if (!target || !isActiveAndEnabled)
            {
                observedTarget = null;
                inside = false;
                return;
            }

            if (observedTarget != target)
            {
                observedTarget = target;
                inside = false;
            }
            Vector3 offset = target.position - transform.position;
            if (plane == MADMovementPlane.XY) offset.z = 0;
            if (plane == MADMovementPlane.XZ) offset.y = 0;
            float remaining = Mathf.Max(0f, offset.magnitude - Mathf.Max(0f, arrivalDistance));
            Vector3 heading = offset.normalized;
            if (remaining > 0.00001f)
            {
                inside = false;
                DesiredVelocity = heading * Mathf.Max(0f, speed);
                if (!moveTransform) return;

                float travel = Mathf.Min(remaining, Mathf.Max(0f, seconds) * DesiredVelocity.magnitude);
                transform.position += heading * travel;
                if (travel < remaining) return;
            }

            DesiredVelocity = Vector3.zero;
            if (inside) return;
            inside = true;
            onArrive.Raise(new MADContext(gameObject, target.gameObject, transform.position, heading));
        }
    }
}
