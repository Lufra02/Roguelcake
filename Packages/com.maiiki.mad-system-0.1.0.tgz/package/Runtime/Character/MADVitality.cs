using UnityEngine;

namespace Maiiki.MAD
{
    /// <summary>Optional health owner for new actors. Call TakeDamage only after the game accepts a hit.</summary>
    [RequireComponent(typeof(MADCharacter)), DisallowMultipleComponent]
    [AddComponentMenu("MAD/Character/Vitality")]
    public sealed class MADVitality : MonoBehaviour
    {
        [SerializeField, Min(0.01f)] private float maximum = 100f;
        private MADCharacter character;
        public float Current { get; private set; }

        private void Awake() => character = GetComponent<MADCharacter>();
        private void OnEnable() => Current = Mathf.Max(0.01f, maximum);

        public bool TakeDamage(float amount, GameObject source)
        {
            if (!isActiveAndEnabled || !character.CanAct || Current <= 0f || !(amount > 0f)) return false;
            Current = Mathf.Max(0f, Current - amount);
            character.NotifyHit(source);
            if (Current <= 0f) character.NotifyDeath(source);
            return true;
        }
    }
}

